-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2021 at 07:37 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sirsak_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `hsi_module_item`
--

CREATE TABLE `hsi_module_item` (
  `item_id` int(11) NOT NULL,
  `item_title` varchar(255) DEFAULT NULL,
  `security_lv_low` varchar(255) DEFAULT NULL,
  `security_lv_medium` varchar(255) DEFAULT NULL,
  `security_lv_high` varchar(255) DEFAULT NULL,
  `additional_note` varchar(255) DEFAULT NULL,
  `item_hazard` varchar(255) DEFAULT NULL,
  `item_weight` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hsi_module_item`
--

INSERT INTO `hsi_module_item` (`item_id`, `item_title`, `security_lv_low`, `security_lv_medium`, `security_lv_high`, `additional_note`, `item_hazard`, `item_weight`) VALUES
(1, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(2, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(3, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(4, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(5, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(6, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(7, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(8, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(9, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(10, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(11, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(12, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(13, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(14, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(15, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(16, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(17, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(18, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(19, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(20, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(21, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(22, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(23, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(24, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(25, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(26, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(27, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(28, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(29, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(30, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(31, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(32, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(33, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(34, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(35, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5),
(36, 'Kerusakan struktural utama sebelumnya atau kegagalan bangunan rumah sakit', 'Terdapat banyak kerusakan dan tidak ada perbaikan', 'Terdapat kerusakan dan hanya sebagian yang diperbaiki', 'Sedikit atau tidak ada kerusakan, atau bangunan sepenuhnya telah diperbaiki', 'JIKA PERISTIWA SEMACAM ITU TIDAK TERJADI DI SEKITAR RUMAH SAKIT, BIARKAN KOTAK TETAP KOSONG DAN BERIKAN KOMENTAR', 'A', 6.25),
(37, 'Rumah sakit dibangun dan/atau diperbaiki menggunakan standar keamanan saat ini', 'Standar keamanan saat ini tidak digunakan', 'Standar keamanan saat ini hanya sebagian saja yang diterapkan dalam pembangunan', 'Standar keamanan saat ini sepenuhnya diterapkan dalam pembangunan', NULL, 'A', 12.5),
(38, 'Efek dari renovasi atau modifikasi pada tampilan struktur rumah sakit', 'Terdapat banyak renovasi atau modifikasi yang dilakukan yang juga memberikan pengaruh besar pada tampilan struktur rumah sakit', 'Renovasi yang cukup dan/atau modifikasi dengan sedikit efek pada tampilan struktur rumah sakit', 'Sedikit renovasi atau modifikasi; tidak ada modifikasi yang dilakukan; atau kebanyakan dari modifikasi berfungsi untuk memperkuat struktur atau tidak mempunyai efek negatif', NULL, 'A', 6.25),
(39, 'Struktur Sistem Desain', 'Memiliki sistem yang buruk', 'Memiliki struktur sistem desain yang moderat', 'Memiliki struktur sistem desain yang baik', NULL, 'A', 7.5),
(40, 'Kondisi Bangunan', 'Retak pada tanah dan lantai; Kerusakan sebagian besar disebabkan oleh cuaca atau lamanya pemakaian', 'Sebagian kerusakan hanya disebabkan oleh cuaca atau lama pemakaian', 'Tidak ada kerusakan atau retak', NULL, 'A', 7.5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hsi_module_item`
--
ALTER TABLE `hsi_module_item`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hsi_module_item`
--
ALTER TABLE `hsi_module_item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
