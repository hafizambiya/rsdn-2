-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2021 at 07:36 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sirsak_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `hsi_module`
--

CREATE TABLE `hsi_module` (
  `module_id` int(11) NOT NULL,
  `module_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hsi_module`
--

INSERT INTO `hsi_module` (`module_id`, `module_name`) VALUES
(1, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(2, 'MODUL 3: Keamanan non struktural'),
(3, 'MODUL 4: Pengelolaan darurat dan bencana'),
(4, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(5, 'MODUL 3: Keamanan non struktural'),
(6, 'MODUL 4: Pengelolaan darurat dan bencana'),
(7, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(8, 'MODUL 3: Keamanan non struktural'),
(9, 'MODUL 4: Pengelolaan darurat dan bencana'),
(10, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(11, 'MODUL 3: Keamanan non struktural'),
(12, 'MODUL 4: Pengelolaan darurat dan bencana'),
(13, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(14, 'MODUL 3: Keamanan non struktural'),
(15, 'MODUL 4: Pengelolaan darurat dan bencana'),
(16, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(17, 'MODUL 3: Keamanan non struktural'),
(18, 'MODUL 4: Pengelolaan darurat dan bencana'),
(19, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(20, 'MODUL 3: Keamanan non struktural'),
(21, 'MODUL 4: Pengelolaan darurat dan bencana'),
(22, 'MODUL 2: Elemen yang terkait dengan keamanan struktural rumah sakit'),
(23, 'MODUL 3: Keamanan non struktural'),
(24, 'MODUL 4: Pengelolaan darurat dan bencana');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hsi_module`
--
ALTER TABLE `hsi_module`
  ADD PRIMARY KEY (`module_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hsi_module`
--
ALTER TABLE `hsi_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
