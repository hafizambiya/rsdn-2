-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2021 at 07:36 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sirsak_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `hsi_module_sublist`
--

CREATE TABLE `hsi_module_sublist` (
  `sublist_id` int(11) NOT NULL,
  `sublist_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hsi_module_sublist`
--

INSERT INTO `hsi_module_sublist` (`sublist_id`, `sublist_name`) VALUES
(1, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(2, '2.2 Integritas Bangunan'),
(3, '3.1 Keamanan arsitektur'),
(4, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(5, '3.3 Sistem kritis'),
(6, '3.4 Peralatan dan perlengkapan'),
(7, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(8, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(9, '4.3 Manajemen komunikasi dan informasi'),
(10, '4.4 Sumber daya manusia'),
(11, '4.5 Logistik dan keuangan'),
(12, '4.6 Layanan dan dukungan pasien'),
(13, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(14, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(15, '2.2 Integritas Bangunan'),
(16, '3.1 Keamanan arsitektur'),
(17, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(18, '3.3 Sistem kritis'),
(19, '3.4 Peralatan dan perlengkapan'),
(20, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(21, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(22, '4.3 Manajemen komunikasi dan informasi'),
(23, '4.4 Sumber daya manusia'),
(24, '4.5 Logistik dan keuangan'),
(25, '4.6 Layanan dan dukungan pasien'),
(26, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(27, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(28, '2.2 Integritas Bangunan'),
(29, '3.1 Keamanan arsitektur'),
(30, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(31, '3.3 Sistem kritis'),
(32, '3.4 Peralatan dan perlengkapan'),
(33, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(34, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(35, '4.3 Manajemen komunikasi dan informasi'),
(36, '4.4 Sumber daya manusia'),
(37, '4.5 Logistik dan keuangan'),
(38, '4.6 Layanan dan dukungan pasien'),
(39, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(40, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(41, '2.2 Integritas Bangunan'),
(42, '3.1 Keamanan arsitektur'),
(43, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(44, '3.3 Sistem kritis'),
(45, '3.4 Peralatan dan perlengkapan'),
(46, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(47, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(48, '4.3 Manajemen komunikasi dan informasi'),
(49, '4.4 Sumber daya manusia'),
(50, '4.5 Logistik dan keuangan'),
(51, '4.6 Layanan dan dukungan pasien'),
(52, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(53, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(54, '2.2 Integritas Bangunan'),
(55, '3.1 Keamanan arsitektur'),
(56, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(57, '3.3 Sistem kritis'),
(58, '3.4 Peralatan dan perlengkapan'),
(59, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(60, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(61, '4.3 Manajemen komunikasi dan informasi'),
(62, '4.4 Sumber daya manusia'),
(63, '4.5 Logistik dan keuangan'),
(64, '4.6 Layanan dan dukungan pasien'),
(65, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(66, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(67, '2.2 Integritas Bangunan'),
(68, '3.1 Keamanan arsitektur'),
(69, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(70, '3.3 Sistem kritis'),
(71, '3.4 Peralatan dan perlengkapan'),
(72, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(73, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(74, '4.3 Manajemen komunikasi dan informasi'),
(75, '4.4 Sumber daya manusia'),
(76, '4.5 Logistik dan keuangan'),
(77, '4.6 Layanan dan dukungan pasien'),
(78, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(79, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(80, '2.2 Integritas Bangunan'),
(81, '3.1 Keamanan arsitektur'),
(82, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(83, '3.3 Sistem kritis'),
(84, '3.4 Peralatan dan perlengkapan'),
(85, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(86, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(87, '4.3 Manajemen komunikasi dan informasi'),
(88, '4.4 Sumber daya manusia'),
(89, '4.5 Logistik dan keuangan'),
(90, '4.6 Layanan dan dukungan pasien'),
(91, '4.7 Evakuasi, dekontaminasi dan keamanan'),
(92, '2.1 Peristiwa dan bahaya sebelumnya yang memengaruhi keamanan bangunan'),
(93, '2.2 Integritas Bangunan'),
(94, '3.1 Keamanan arsitektur'),
(95, '3.2 Perlindungan infrastruktur, akses, dan keamanan fisik'),
(96, '3.3 Sistem kritis'),
(97, '3.4 Peralatan dan perlengkapan'),
(98, '4.1 Koordinasi manajemen pada saat keadaan darurat dan bencana'),
(99, '4.2 Respon dan rencana pemulihan rumah sakit untuk keadaan darurat dan bencana'),
(100, '4.3 Manajemen komunikasi dan informasi'),
(101, '4.4 Sumber daya manusia'),
(102, '4.5 Logistik dan keuangan'),
(103, '4.6 Layanan dan dukungan pasien'),
(104, '4.7 Evakuasi, dekontaminasi dan keamanan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hsi_module_sublist`
--
ALTER TABLE `hsi_module_sublist`
  ADD PRIMARY KEY (`sublist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hsi_module_sublist`
--
ALTER TABLE `hsi_module_sublist`
  MODIFY `sublist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
