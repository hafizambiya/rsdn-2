<?php

include("../../lib/inc/config.php");

if(session_id() == '') {
    session_start();
}

function result_to_array($result) {
    $rows = array();
    while($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

$result = mysqli_query($conn, "SELECT * FROM hsi_module_result WHERE result_id = " . $_GET['id']);
$rows = result_to_array($result);
$json = json_decode(utf8_decode($rows[0]["json_result"]), true);

$percentages = [];
foreach($json["modules"] as $module) {
    $module_id = $module["module_id"];
    $blank = $rendah = $sedang = $tinggi = 0;

    foreach($module["sublists"] as $sublist) {
        foreach($sublist["items"] as $item) {
            if($item["answer"] == "Blank") $blank++;
            if($item["answer"] == "Rendah") $rendah++;
            if($item["answer"] == "Sedang") $sedang++;
            if($item["answer"] == "Tinggi") $tinggi++;
        }
    }

    $array = array("module_id" => $module_id, "blank" => $blank, "rendah" => $rendah, "sedang" => $sedang, "tinggi" => $tinggi);
    $percentages[] = $array;
}

echo json_encode($percentages);